﻿using System;
using DIO.Entities;

namespace DIO
{
    class Program
    {
        static void Main(string[] args)
        {
            Hero arus = new Hero("Arus", 23, "Knight");
            Hero oponnet = new Hero("Maleficus", 99, "Devil");
            Wizard wizard = new Wizard("Jennica ", 23, "White Wizard");

            
            Console.WriteLine(Wizard.Attack(1))
            )
        }
    }
}
