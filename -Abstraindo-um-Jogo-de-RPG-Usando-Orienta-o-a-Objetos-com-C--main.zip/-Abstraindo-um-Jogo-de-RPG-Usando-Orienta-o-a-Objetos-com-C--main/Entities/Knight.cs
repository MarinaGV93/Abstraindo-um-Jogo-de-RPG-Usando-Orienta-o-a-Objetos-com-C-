namespace DIO.Entities
{
    public class Knight
    {
         public Knight(string Name, int Level, string HeroType){

             this.Name = Name;
            this.Level = Level;
            this.HeroType = HeroType;
    }
}